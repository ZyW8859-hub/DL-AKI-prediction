"""
Data Preprocessing Module for MIMIC-IV AKI Prediction
Handles data loading, cleaning, and feature engineering
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.impute import SimpleImputer, KNNImputer
from typing import Tuple, Dict, List
import warnings
warnings.filterwarnings('ignore')


class MIMICDataProcessor:
    """
    Process MIMIC-IV data for AKI prediction
    """
    
    def __init__(self, data_path: str, prediction_window: int = 24):
        """
        Initialize data processor
        
        Args:
            data_path: Path to MIMIC-IV demo dataset
            prediction_window: Hours before AKI onset to predict (24 or 48)
        """
        self.data_path = data_path
        self.prediction_window = prediction_window
        self.scaler = RobustScaler()  # Robust to outliers
        self.imputer = KNNImputer(n_neighbors=5)
        
        # Define important features for AKI prediction
        self.vital_features = [
            'heart_rate', 'sbp', 'dbp', 'mean_bp', 'resp_rate',
            'temperature', 'spo2', 'glucose'
        ]
        
        self.lab_features = [
            'creatinine', 'bun', 'bicarbonate', 'chloride',
            'hemoglobin', 'platelet', 'potassium', 'sodium',
            'white_blood_cells', 'lactate', 'ph', 'pco2', 'po2'
        ]
        
        self.demographic_features = [
            'age', 'gender', 'weight', 'height', 'bmi'
        ]
        
    def load_data(self) -> pd.DataFrame:
        """
        Load and merge MIMIC-IV tables
        
        Returns:
            Merged dataframe with patient data
        """
        # Load core tables (simplified for demo)
        print("Loading MIMIC-IV data...")
        
        # In practice, load actual MIMIC-IV tables
        # For demo, we'll create synthetic data structure
        patients = self._load_patients()
        admissions = self._load_admissions()
        lab_events = self._load_lab_events()
        chart_events = self._load_chart_events()
        
        # Merge tables
        data = self._merge_tables(patients, admissions, lab_events, chart_events)
        
        return data
    
    def _load_patients(self) -> pd.DataFrame:
        """Load patient demographics"""
        # Simplified for demo - in practice, read from CSV
        n_patients = 1000
        np.random.seed(42)
        
        patients = pd.DataFrame({
            'subject_id': range(1, n_patients + 1),
            'gender': np.random.choice(['M', 'F'], n_patients),
            'anchor_age': np.random.normal(65, 15, n_patients).clip(18, 90),
            'weight': np.random.normal(75, 20, n_patients).clip(40, 150),
            'height': np.random.normal(170, 15, n_patients).clip(140, 200)
        })
        
        patients['bmi'] = patients['weight'] / ((patients['height'] / 100) ** 2)
        
        return patients
    
    def _load_admissions(self) -> pd.DataFrame:
        """Load admission data"""
        # Simplified for demo
        n_admissions = 1500
        np.random.seed(43)
        
        admissions = pd.DataFrame({
            'hadm_id': range(1, n_admissions + 1),
            'subject_id': np.random.choice(range(1, 1001), n_admissions),
            'admittime': pd.date_range('2020-01-01', periods=n_admissions, freq='12H'),
            'dischtime': pd.date_range('2020-01-05', periods=n_admissions, freq='12H')
        })
        
        return admissions
    
    def _load_lab_events(self) -> pd.DataFrame:
        """Load laboratory events"""
        # Generate synthetic lab data for demo
        n_events = 10000
        np.random.seed(44)
        
        lab_events = pd.DataFrame({
            'hadm_id': np.random.choice(range(1, 1501), n_events),
            'charttime': pd.date_range('2020-01-01', periods=n_events, freq='1H'),
            'creatinine': np.random.lognormal(0, 0.5, n_events).clip(0.5, 5),
            'bun': np.random.normal(20, 10, n_events).clip(5, 100),
            'potassium': np.random.normal(4, 0.5, n_events).clip(2.5, 6),
            'sodium': np.random.normal(140, 5, n_events).clip(120, 160),
            'bicarbonate': np.random.normal(24, 3, n_events).clip(15, 35),
            'chloride': np.random.normal(100, 5, n_events).clip(80, 120),
            'hemoglobin': np.random.normal(12, 2, n_events).clip(6, 18),
            'platelet': np.random.normal(250, 100, n_events).clip(50, 500),
            'white_blood_cells': np.random.normal(10, 3, n_events).clip(2, 20),
            'lactate': np.random.lognormal(0.5, 0.5, n_events).clip(0.5, 10)
        })
        
        return lab_events
    
    def _load_chart_events(self) -> pd.DataFrame:
        """Load chart events (vital signs)"""
        # Generate synthetic vital signs for demo
        n_events = 20000
        np.random.seed(45)
        
        chart_events = pd.DataFrame({
            'hadm_id': np.random.choice(range(1, 1501), n_events),
            'charttime': pd.date_range('2020-01-01', periods=n_events, freq='30min'),
            'heart_rate': np.random.normal(80, 15, n_events).clip(40, 150),
            'sbp': np.random.normal(120, 20, n_events).clip(70, 180),
            'dbp': np.random.normal(70, 10, n_events).clip(40, 100),
            'mean_bp': np.random.normal(85, 12, n_events).clip(50, 120),
            'resp_rate': np.random.normal(18, 4, n_events).clip(8, 35),
            'temperature': np.random.normal(37, 0.5, n_events).clip(35, 40),
            'spo2': np.random.normal(96, 3, n_events).clip(85, 100),
            'glucose': np.random.normal(110, 30, n_events).clip(50, 300)
        })
        
        return chart_events
    
    def _merge_tables(self, patients, admissions, lab_events, chart_events) -> pd.DataFrame:
        """Merge all tables into single dataframe"""
        # Merge patients with admissions
        data = pd.merge(admissions, patients, on='subject_id')
        
        # Aggregate lab and chart events by admission
        lab_agg = lab_events.groupby('hadm_id').mean()
        chart_agg = chart_events.groupby('hadm_id').mean()
        
        # Merge with main data
        data = pd.merge(data, lab_agg, left_on='hadm_id', right_index=True, how='left')
        data = pd.merge(data, chart_agg, left_on='hadm_id', right_index=True, how='left')
        
        return data
    
    def apply_kdigo_criteria(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Apply KDIGO criteria for AKI staging
        
        KDIGO Criteria:
        - Stage 1: Cr increase ≥0.3 mg/dl or 1.5-1.9x baseline
        - Stage 2: Cr 2.0-2.9x baseline  
        - Stage 3: Cr ≥3.0x baseline or ≥4.0 mg/dl or RRT initiation
        
        Args:
            data: Patient data
            
        Returns:
            Data with AKI labels
        """
        print("Applying KDIGO criteria for AKI staging...")
        
        # Calculate baseline creatinine (first value or lowest in first 24h)
        baseline_cr = data.groupby('hadm_id')['creatinine'].first()
        
        # Calculate maximum creatinine during stay
        max_cr = data.groupby('hadm_id')['creatinine'].max()
        
        # Calculate creatinine increase
        cr_increase = max_cr - baseline_cr
        cr_ratio = max_cr / baseline_cr
        
        # Apply KDIGO staging
        aki_stage = pd.Series(0, index=cr_ratio.index)  # No AKI
        
        # Stage 1
        stage1_mask = (cr_increase >= 0.3) | ((cr_ratio >= 1.5) & (cr_ratio < 2.0))
        aki_stage[stage1_mask] = 1
        
        # Stage 2
        stage2_mask = (cr_ratio >= 2.0) & (cr_ratio < 3.0)
        aki_stage[stage2_mask] = 2
        
        # Stage 3
        stage3_mask = (cr_ratio >= 3.0) | (max_cr >= 4.0)
        aki_stage[stage3_mask] = 3
        
        # Add AKI labels to data
        data['aki_stage'] = data['hadm_id'].map(aki_stage)
        data['aki_binary'] = (data['aki_stage'] > 0).astype(int)
        
        print(f"AKI distribution: {data['aki_stage'].value_counts().sort_index()}")
        
        return data
    
    def create_temporal_features(self, data: pd.DataFrame) -> np.ndarray:
        """
        Create temporal features for time series modeling
        
        Args:
            data: Patient data
            
        Returns:
            3D array of shape (n_patients, time_steps, n_features)
        """
        print("Creating temporal features...")
        
        # Group by patient admission
        grouped = data.groupby('hadm_id')
        
        # Fixed sequence length (e.g., 48 hours of hourly data)
        seq_length = 48
        n_features = len(self.vital_features) + len(self.lab_features)
        
        # Initialize arrays
        n_patients = len(grouped)
        X = np.zeros((n_patients, seq_length, n_features))
        
        # Extract temporal sequences for each patient
        for i, (hadm_id, group) in enumerate(grouped):
            # Combine vital and lab features
            features = group[self.vital_features + self.lab_features].values
            
            # Pad or truncate to fixed length
            if len(features) >= seq_length:
                X[i] = features[:seq_length]
            else:
                X[i, :len(features)] = features
                
        return X
    
    def handle_missing_values(self, X: np.ndarray) -> np.ndarray:
        """
        Handle missing values in temporal data
        
        Args:
            X: Temporal feature array
            
        Returns:
            Imputed array
        """
        print("Handling missing values...")
        
        # Reshape for imputation
        n_samples, n_timesteps, n_features = X.shape
        X_reshaped = X.reshape(n_samples * n_timesteps, n_features)
        
        # Apply KNN imputation
        X_imputed = self.imputer.fit_transform(X_reshaped)
        
        # Reshape back
        X_imputed = X_imputed.reshape(n_samples, n_timesteps, n_features)
        
        # Forward fill remaining NaNs
        X_imputed = pd.DataFrame(X_imputed.reshape(-1, n_features)).fillna(method='ffill').fillna(0).values
        X_imputed = X_imputed.reshape(n_samples, n_timesteps, n_features)
        
        return X_imputed
    
    def normalize_features(self, X: np.ndarray) -> np.ndarray:
        """
        Normalize features using robust scaling
        
        Args:
            X: Feature array
            
        Returns:
            Normalized array
        """
        print("Normalizing features...")
        
        # Reshape for normalization
        n_samples, n_timesteps, n_features = X.shape
        X_reshaped = X.reshape(n_samples * n_timesteps, n_features)
        
        # Apply robust scaling
        X_normalized = self.scaler.fit_transform(X_reshaped)
        
        # Reshape back
        X_normalized = X_normalized.reshape(n_samples, n_timesteps, n_features)
        
        return X_normalized
    
    def prepare_data(self) -> Tuple[np.ndarray, np.ndarray, Dict]:
        """
        Complete data preparation pipeline
        
        Returns:
            X: Processed feature array
            y: Target labels
            info: Additional information dictionary
        """
        # Load data
        data = self.load_data()
        
        # Apply KDIGO criteria
        data = self.apply_kdigo_criteria(data)
        
        # Create temporal features
        X = self.create_temporal_features(data)
        
        # Handle missing values
        X = self.handle_missing_values(X)
        
        # Normalize features
        X = self.normalize_features(X)
        
        # Extract labels
        y = data.groupby('hadm_id')['aki_binary'].first().values
        
        # Create info dictionary
        info = {
            'n_samples': len(X),
            'n_features': X.shape[2],
            'seq_length': X.shape[1],
            'aki_rate': y.mean(),
            'feature_names': self.vital_features + self.lab_features
        }
        
        print(f"\nData prepared: {info['n_samples']} samples, {info['aki_rate']:.2%} AKI rate")
        
        return X, y, info


if __name__ == "__main__":
    # Example usage
    processor = MIMICDataProcessor(data_path="data/mimic-iv-demo/", prediction_window=24)
    X, y, info = processor.prepare_data()
    print(f"Data shape: {X.shape}, Labels shape: {y.shape}")
    print(f"Info: {info}")
