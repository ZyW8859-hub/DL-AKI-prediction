"""
CNN+BiLSTM+Attention Model for AKI Prediction
Combines local pattern extraction, bidirectional temporal modeling, and attention
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Optional, Tuple


class AttentionLayer(nn.Module):
    """
    Attention mechanism for weighted temporal aggregation
    """
    
    def __init__(self, hidden_size: int):
        """
        Initialize attention layer
        
        Args:
            hidden_size: Size of hidden representation
        """
        super(AttentionLayer, self).__init__()
        self.hidden_size = hidden_size
        
        # Attention weights computation
        self.W_attention = nn.Linear(hidden_size, hidden_size)
        self.V_attention = nn.Linear(hidden_size, 1, bias=False)
        
    def forward(self, hidden_states: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply attention mechanism
        
        Args:
            hidden_states: Sequence hidden states (batch, seq_len, hidden)
            
        Returns:
            context: Weighted context vector
            attention_weights: Attention weights for visualization
        """
        # Calculate attention scores
        # (batch, seq_len, hidden) -> (batch, seq_len, hidden)
        attention_hidden = torch.tanh(self.W_attention(hidden_states))
        
        # (batch, seq_len, hidden) -> (batch, seq_len, 1)
        attention_scores = self.V_attention(attention_hidden)
        
        # Apply softmax to get attention weights
        # (batch, seq_len, 1) -> (batch, seq_len, 1)
        attention_weights = F.softmax(attention_scores, dim=1)
        
        # Apply attention weights to hidden states
        # (batch, seq_len, hidden) * (batch, seq_len, 1) -> (batch, hidden)
        context = torch.sum(hidden_states * attention_weights, dim=1)
        
        return context, attention_weights.squeeze(-1)


class CNNBiLSTMAttention(nn.Module):
    """
    CNN+BiLSTM+Attention architecture for AKI prediction
    Designed for superior performance on irregular ICU time series
    """
    
    def __init__(
        self,
        n_features: int,
        seq_length: int,
        cnn_filters: list = [32, 64, 128],
        cnn_kernel_sizes: list = [3, 5, 7],
        lstm_hidden_size: int = 128,
        lstm_num_layers: int = 2,
        dropout_rate: float = 0.3,
        n_classes: int = 2
    ):
        """
        Initialize CNN+BiLSTM+Attention model
        
        Args:
            n_features: Number of input features
            seq_length: Length of input sequences
            cnn_filters: Number of filters for each CNN layer
            cnn_kernel_sizes: Kernel sizes for CNN layers
            lstm_hidden_size: Hidden size for LSTM
            lstm_num_layers: Number of LSTM layers
            dropout_rate: Dropout probability
            n_classes: Number of output classes
        """
        super(CNNBiLSTMAttention, self).__init__()
        
        self.n_features = n_features
        self.seq_length = seq_length
        self.lstm_hidden_size = lstm_hidden_size
        self.n_classes = n_classes
        
        # 1. CNN layers for local pattern extraction
        self.cnn_layers = nn.ModuleList()
        in_channels = n_features
        
        for filters, kernel_size in zip(cnn_filters, cnn_kernel_sizes):
            conv_block = nn.Sequential(
                # 1D Convolution along time axis
                nn.Conv1d(
                    in_channels=in_channels,
                    out_channels=filters,
                    kernel_size=kernel_size,
                    padding=kernel_size // 2  # Same padding
                ),
                nn.BatchNorm1d(filters),
                nn.ReLU(),
                nn.MaxPool1d(kernel_size=2, stride=1, padding=1),
                nn.Dropout(dropout_rate)
            )
            self.cnn_layers.append(conv_block)
            in_channels = filters
        
        # Calculate CNN output size
        cnn_output_size = cnn_filters[-1]
        
        # 2. BiLSTM layers for temporal modeling
        self.lstm = nn.LSTM(
            input_size=cnn_output_size,
            hidden_size=lstm_hidden_size,
            num_layers=lstm_num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout_rate if lstm_num_layers > 1 else 0
        )
        
        # BiLSTM output size (bidirectional doubles the size)
        lstm_output_size = lstm_hidden_size * 2
        
        # 3. Attention layer for weighted aggregation
        self.attention = AttentionLayer(lstm_output_size)
        
        # 4. Classification head
        self.classifier = nn.Sequential(
            nn.Linear(lstm_output_size, lstm_hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(lstm_hidden_size, lstm_hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(lstm_hidden_size // 2, n_classes)
        )
        
        # Initialize weights
        self._init_weights()
        
    def _init_weights(self):
        """Initialize model weights"""
        for module in self.modules():
            if isinstance(module, nn.Conv1d):
                nn.init.kaiming_normal_(module.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(module, nn.Linear):
                nn.init.xavier_normal_(module.weight)
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
            elif isinstance(module, nn.LSTM):
                for name, param in module.named_parameters():
                    if 'weight_ih' in name:
                        nn.init.xavier_uniform_(param.data)
                    elif 'weight_hh' in name:
                        nn.init.orthogonal_(param.data)
                    elif 'bias' in name:
                        nn.init.constant_(param.data, 0)
                        
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass through the model
        
        Args:
            x: Input tensor (batch, seq_length, n_features)
            
        Returns:
            output: Classification logits
            attention_weights: Attention weights for interpretation
        """
        batch_size, seq_len, n_features = x.shape
        
        # 1. CNN feature extraction
        # Transpose for Conv1d: (batch, features, seq_len)
        x = x.transpose(1, 2)
        
        # Apply CNN layers
        for cnn_layer in self.cnn_layers:
            x = cnn_layer(x)
        
        # Transpose back: (batch, seq_len, channels)
        x = x.transpose(1, 2)
        
        # 2. BiLSTM temporal modeling
        lstm_out, (hidden, cell) = self.lstm(x)
        # lstm_out shape: (batch, seq_len, hidden_size * 2)
        
        # 3. Apply attention mechanism
        context, attention_weights = self.attention(lstm_out)
        # context shape: (batch, hidden_size * 2)
        
        # 4. Classification
        output = self.classifier(context)
        
        return output, attention_weights
    
    def predict_proba(self, x: torch.Tensor) -> np.ndarray:
        """
        Predict probabilities
        
        Args:
            x: Input tensor
            
        Returns:
            Probabilities for each class
        """
        self.eval()
        with torch.no_grad():
            logits, _ = self.forward(x)
            probs = F.softmax(logits, dim=-1)
        return probs.cpu().numpy()
    
    def get_attention_weights(self, x: torch.Tensor) -> np.ndarray:
        """
        Get attention weights for interpretation
        
        Args:
            x: Input tensor
            
        Returns:
            Attention weights
        """
        self.eval()
        with torch.no_grad():
            _, attention_weights = self.forward(x)
        return attention_weights.cpu().numpy()


class CNNBiLSTMAttentionWrapper:
    """
    Wrapper class for training and evaluation
    """
    
    def __init__(self, model: CNNBiLSTMAttention, device: str = 'cuda'):
        """
        Initialize wrapper
        
        Args:
            model: CNN+BiLSTM+Attention model
            device: Computing device
        """
        self.model = model.to(device)
        self.device = device
        self.optimizer = None
        self.criterion = None
        
    def compile(self, learning_rate: float = 0.001, weight_decay: float = 1e-5):
        """
        Compile model with optimizer and loss
        
        Args:
            learning_rate: Learning rate
            weight_decay: L2 regularization
        """
        self.optimizer = torch.optim.Adam(
            self.model.parameters(),
            lr=learning_rate,
            weight_decay=weight_decay
        )
        
        # Use weighted cross-entropy for class imbalance
        self.criterion = nn.CrossEntropyLoss()
        
    def train_step(self, X: torch.Tensor, y: torch.Tensor) -> float:
        """
        Single training step
        
        Args:
            X: Input batch
            y: Target batch
            
        Returns:
            Loss value
        """
        self.model.train()
        
        # Move to device
        X = X.to(self.device)
        y = y.to(self.device)
        
        # Forward pass
        logits, _ = self.model(X)
        loss = self.criterion(logits, y)
        
        # Backward pass
        self.optimizer.zero_grad()
        loss.backward()
        
        # Gradient clipping for stability
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
        
        self.optimizer.step()
        
        return loss.item()
    
    def evaluate(self, X: torch.Tensor, y: torch.Tensor) -> dict:
        """
        Evaluate model
        
        Args:
            X: Input data
            y: Target data
            
        Returns:
            Evaluation metrics
        """
        self.model.eval()
        
        with torch.no_grad():
            X = X.to(self.device)
            y = y.to(self.device)
            
            logits, _ = self.model(X)
            loss = self.criterion(logits, y).item()
            
            # Calculate accuracy
            predictions = torch.argmax(logits, dim=-1)
            accuracy = (predictions == y).float().mean().item()
            
            # Calculate probabilities for AUPRC
            probs = F.softmax(logits, dim=-1)[:, 1].cpu().numpy()
            
        return {
            'loss': loss,
            'accuracy': accuracy,
            'probabilities': probs,
            'predictions': predictions.cpu().numpy()
        }


def create_cnn_bilstm_attention_model(
    n_features: int,
    seq_length: int,
    **kwargs
) -> CNNBiLSTMAttention:
    """
    Factory function to create CNN+BiLSTM+Attention model
    
    Args:
        n_features: Number of features
        seq_length: Sequence length
        **kwargs: Additional model parameters
        
    Returns:
        Configured model
    """
    model = CNNBiLSTMAttention(
        n_features=n_features,
        seq_length=seq_length,
        **kwargs
    )
    
    print(f"CNN+BiLSTM+Attention Model created:")
    print(f"  - Parameters: {sum(p.numel() for p in model.parameters()):,}")
    print(f"  - Trainable: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")
    
    return model


if __name__ == "__main__":
    # Test the model
    batch_size = 32
    seq_length = 48
    n_features = 25
    
    # Create model
    model = create_cnn_bilstm_attention_model(n_features, seq_length)
    
    # Test forward pass
    x = torch.randn(batch_size, seq_length, n_features)
    output, attention = model(x)
    
    print(f"\nTest forward pass:")
    print(f"  Input shape: {x.shape}")
    print(f"  Output shape: {output.shape}")
    print(f"  Attention shape: {attention.shape}")
