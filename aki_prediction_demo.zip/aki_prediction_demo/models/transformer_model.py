"""
Transformer Model for AKI Prediction
Self-attention based architecture for comparison with CNN+BiLSTM+Attention
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import math
from typing import Optional, Tuple


class PositionalEncoding(nn.Module):
    """
    Positional encoding for transformer
    """
    
    def __init__(self, d_model: int, max_len: int = 5000):
        """
        Initialize positional encoding
        
        Args:
            d_model: Model dimension
            max_len: Maximum sequence length
        """
        super(PositionalEncoding, self).__init__()
        
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * 
                           (-math.log(10000.0) / d_model))
        
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Add positional encoding
        
        Args:
            x: Input tensor (seq_len, batch, d_model)
            
        Returns:
            Tensor with positional encoding
        """
        x = x + self.pe[:x.size(0), :]
        return x


class TransformerAKIPredictor(nn.Module):
    """
    Transformer architecture for AKI prediction
    """
    
    def __init__(
        self,
        n_features: int,
        seq_length: int,
        d_model: int = 128,
        n_heads: int = 8,
        n_layers: int = 4,
        d_ff: int = 512,
        dropout_rate: float = 0.3,
        n_classes: int = 2
    ):
        """
        Initialize Transformer model
        
        Args:
            n_features: Number of input features
            seq_length: Length of input sequences
            d_model: Model dimension
            n_heads: Number of attention heads
            n_layers: Number of transformer layers
            d_ff: Feed-forward dimension
            dropout_rate: Dropout probability
            n_classes: Number of output classes
        """
        super(TransformerAKIPredictor, self).__init__()
        
        self.n_features = n_features
        self.seq_length = seq_length
        self.d_model = d_model
        
        # Input projection
        self.input_projection = nn.Linear(n_features, d_model)
        
        # Positional encoding
        self.pos_encoder = PositionalEncoding(d_model, max_len=seq_length)
        
        # Transformer encoder layers
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout_rate,
            activation='relu',
            batch_first=False  # Standard transformer uses (seq, batch, features)
        )
        
        self.transformer_encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=n_layers,
            norm=nn.LayerNorm(d_model)
        )
        
        # Global pooling strategies
        self.use_cls_token = True
        if self.use_cls_token:
            # CLS token for classification
            self.cls_token = nn.Parameter(torch.randn(1, 1, d_model))
        
        # Classification head
        self.classifier = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(d_model // 2, d_model // 4),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(d_model // 4, n_classes)
        )
        
        # Initialize weights
        self._init_weights()
        
    def _init_weights(self):
        """Initialize model weights"""
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
                
    def _generate_square_subsequent_mask(self, sz: int) -> torch.Tensor:
        """
        Generate causal mask for autoregressive modeling
        
        Args:
            sz: Sequence size
            
        Returns:
            Mask tensor
        """
        mask = (torch.triu(torch.ones(sz, sz)) == 1).transpose(0, 1)
        mask = mask.float().masked_fill(mask == 0, float('-inf')).masked_fill(mask == 1, float(0.0))
        return mask
    
    def forward(self, x: torch.Tensor, mask: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass through transformer
        
        Args:
            x: Input tensor (batch, seq_length, n_features)
            mask: Optional attention mask
            
        Returns:
            output: Classification logits
            attention_weights: Self-attention weights
        """
        batch_size, seq_len, _ = x.shape
        
        # Project input to model dimension
        x = self.input_projection(x)  # (batch, seq, d_model)
        
        # Add CLS token if using
        if self.use_cls_token:
            cls_tokens = self.cls_token.expand(batch_size, -1, -1)
            x = torch.cat([cls_tokens, x], dim=1)  # (batch, seq+1, d_model)
            seq_len += 1
        
        # Transpose for transformer: (seq, batch, d_model)
        x = x.transpose(0, 1)
        
        # Add positional encoding
        x = self.pos_encoder(x)
        
        # Generate padding mask if needed
        if mask is None:
            # For autoregressive modeling (optional)
            # mask = self._generate_square_subsequent_mask(seq_len).to(x.device)
            mask = None  # No mask for bidirectional attention
        
        # Pass through transformer encoder
        transformer_out = self.transformer_encoder(x, mask=mask)
        # transformer_out shape: (seq, batch, d_model)
        
        # Extract representation for classification
        if self.use_cls_token:
            # Use CLS token representation
            output_representation = transformer_out[0]  # (batch, d_model)
        else:
            # Use mean pooling over sequence
            output_representation = transformer_out.mean(dim=0)  # (batch, d_model)
        
        # Classification
        logits = self.classifier(output_representation)
        
        # Extract attention weights (simplified - would need custom transformer for full weights)
        attention_weights = torch.ones(batch_size, seq_len - 1 if self.use_cls_token else seq_len)
        
        return logits, attention_weights
    
    def predict_proba(self, x: torch.Tensor) -> np.ndarray:
        """
        Predict probabilities
        
        Args:
            x: Input tensor
            
        Returns:
            Probabilities for each class
        """
        self.eval()
        with torch.no_grad():
            logits, _ = self.forward(x)
            probs = F.softmax(logits, dim=-1)
        return probs.cpu().numpy()


class TransformerWrapper:
    """
    Wrapper class for training and evaluation
    """
    
    def __init__(self, model: TransformerAKIPredictor, device: str = 'cuda'):
        """
        Initialize wrapper
        
        Args:
            model: Transformer model
            device: Computing device
        """
        self.model = model.to(device)
        self.device = device
        self.optimizer = None
        self.criterion = None
        self.scheduler = None
        
    def compile(self, learning_rate: float = 0.0001, weight_decay: float = 1e-5):
        """
        Compile model with optimizer and loss
        
        Args:
            learning_rate: Learning rate
            weight_decay: L2 regularization
        """
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=learning_rate,
            weight_decay=weight_decay
        )
        
        # Learning rate scheduler with warmup
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            self.optimizer,
            T_0=10,
            T_mult=2
        )
        
        # Use weighted cross-entropy for class imbalance
        self.criterion = nn.CrossEntropyLoss()
        
    def train_step(self, X: torch.Tensor, y: torch.Tensor) -> float:
        """
        Single training step
        
        Args:
            X: Input batch
            y: Target batch
            
        Returns:
            Loss value
        """
        self.model.train()
        
        # Move to device
        X = X.to(self.device)
        y = y.to(self.device)
        
        # Forward pass
        logits, _ = self.model(X)
        loss = self.criterion(logits, y)
        
        # Backward pass
        self.optimizer.zero_grad()
        loss.backward()
        
        # Gradient clipping
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
        
        self.optimizer.step()
        
        # Update learning rate
        if self.scheduler:
            self.scheduler.step()
        
        return loss.item()
    
    def evaluate(self, X: torch.Tensor, y: torch.Tensor) -> dict:
        """
        Evaluate model
        
        Args:
            X: Input data
            y: Target data
            
        Returns:
            Evaluation metrics
        """
        self.model.eval()
        
        with torch.no_grad():
            X = X.to(self.device)
            y = y.to(self.device)
            
            logits, _ = self.model(X)
            loss = self.criterion(logits, y).item()
            
            # Calculate accuracy
            predictions = torch.argmax(logits, dim=-1)
            accuracy = (predictions == y).float().mean().item()
            
            # Calculate probabilities for AUPRC
            probs = F.softmax(logits, dim=-1)[:, 1].cpu().numpy()
            
        return {
            'loss': loss,
            'accuracy': accuracy,
            'probabilities': probs,
            'predictions': predictions.cpu().numpy()
        }


def create_transformer_model(
    n_features: int,
    seq_length: int,
    **kwargs
) -> TransformerAKIPredictor:
    """
    Factory function to create Transformer model
    
    Args:
        n_features: Number of features
        seq_length: Sequence length
        **kwargs: Additional model parameters
        
    Returns:
        Configured model
    """
    model = TransformerAKIPredictor(
        n_features=n_features,
        seq_length=seq_length,
        **kwargs
    )
    
    print(f"Transformer Model created:")
    print(f"  - Parameters: {sum(p.numel() for p in model.parameters()):,}")
    print(f"  - Trainable: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")
    
    return model


if __name__ == "__main__":
    # Test the model
    batch_size = 32
    seq_length = 48
    n_features = 25
    
    # Create model
    model = create_transformer_model(n_features, seq_length)
    
    # Test forward pass
    x = torch.randn(batch_size, seq_length, n_features)
    output, attention = model(x)
    
    print(f"\nTest forward pass:")
    print(f"  Input shape: {x.shape}")
    print(f"  Output shape: {output.shape}")
    print(f"  Attention shape: {attention.shape}")
