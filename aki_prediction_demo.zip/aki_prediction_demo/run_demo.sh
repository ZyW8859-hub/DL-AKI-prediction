#!/bin/bash

# Run AKI Prediction Demo
# Comparing CNN+BiLSTM+Attention vs Transformer

echo "=============================================="
echo "AKI Prediction Demo"
echo "CNN+BiLSTM+Attention vs Transformer"
echo "=============================================="

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install requirements
echo "Installing requirements..."
pip install -q -r requirements.txt

# Create necessary directories
mkdir -p data/mimic-iv-demo
mkdir -p results
mkdir -p models/saved

# Download data if not present (placeholder - actual data needs Kaggle API)
if [ ! -f "data/mimic-iv-demo/patients.csv" ]; then
    echo ""
    echo "Please download MIMIC-IV demo data from:"
    echo "https://www.kaggle.com/datasets/montassarba/mimic-iv-clinical-database-demo-2-2"
    echo "And extract to data/mimic-iv-demo/"
    echo ""
fi

# Run main training script
echo "Starting training..."
python main.py \
    --model both \
    --prediction_window 24 \
    --epochs 50 \
    --batch_size 32

echo ""
echo "=============================================="
echo "Training complete! Check results/ directory"
echo "=============================================="
