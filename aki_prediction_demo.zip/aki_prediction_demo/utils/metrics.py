"""
Evaluation Metrics Module for AKI Prediction
Implements AUPRC, Sensitivity, and Early Prediction Accuracy
"""

import numpy as np
import torch
from sklearn.metrics import (
    precision_recall_curve, auc, roc_auc_score,
    confusion_matrix, classification_report,
    accuracy_score, recall_score, precision_score, f1_score
)
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, Tuple, Optional


class AKIMetrics:
    """
    Comprehensive metrics for AKI prediction evaluation
    """
    
    def __init__(self, prediction_window: int = 24):
        """
        Initialize metrics calculator
        
        Args:
            prediction_window: Hours before AKI onset (24 or 48)
        """
        self.prediction_window = prediction_window
        self.results = {}
        
    def calculate_auprc(self, y_true: np.ndarray, y_proba: np.ndarray) -> float:
        """
        Calculate Area Under Precision-Recall Curve
        
        Args:
            y_true: True labels
            y_proba: Predicted probabilities
            
        Returns:
            AUPRC score
        """
        precision, recall, _ = precision_recall_curve(y_true, y_proba)
        auprc = auc(recall, precision)
        
        # Store for plotting
        self.results['precision'] = precision
        self.results['recall'] = recall
        self.results['auprc'] = auprc
        
        return auprc
    
    def calculate_sensitivity(self, y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """
        Calculate sensitivity (recall) for AKI detection
        
        Args:
            y_true: True labels
            y_pred: Predicted labels
            
        Returns:
            Sensitivity score
        """
        sensitivity = recall_score(y_true, y_pred, pos_label=1)
        self.results['sensitivity'] = sensitivity
        return sensitivity
    
    def calculate_early_prediction_accuracy(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        timestamps: Optional[np.ndarray] = None
    ) -> float:
        """
        Calculate accuracy within the early prediction window
        
        Args:
            y_true: True labels
            y_pred: Predicted labels
            timestamps: Optional timestamps for temporal filtering
            
        Returns:
            Early prediction accuracy
        """
        if timestamps is not None:
            # Filter predictions within the prediction window
            window_mask = (timestamps >= -self.prediction_window - 24) & \
                         (timestamps <= -self.prediction_window)
            y_true_window = y_true[window_mask]
            y_pred_window = y_pred[window_mask]
        else:
            y_true_window = y_true
            y_pred_window = y_pred
        
        early_accuracy = accuracy_score(y_true_window, y_pred_window)
        self.results['early_accuracy'] = early_accuracy
        return early_accuracy
    
    def calculate_all_metrics(
        self,
        y_true: np.ndarray,
        y_proba: np.ndarray,
        threshold: float = 0.5
    ) -> Dict[str, float]:
        """
        Calculate all evaluation metrics
        
        Args:
            y_true: True labels
            y_proba: Predicted probabilities
            threshold: Classification threshold
            
        Returns:
            Dictionary of all metrics
        """
        # Convert probabilities to predictions
        y_pred = (y_proba >= threshold).astype(int)
        
        # Calculate metrics
        metrics = {
            'auprc': self.calculate_auprc(y_true, y_proba),
            'sensitivity': self.calculate_sensitivity(y_true, y_pred),
            'early_accuracy': self.calculate_early_prediction_accuracy(y_true, y_pred),
            'auroc': roc_auc_score(y_true, y_proba),
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred, pos_label=1),
            'specificity': recall_score(y_true, y_pred, pos_label=0),
            'f1_score': f1_score(y_true, y_pred),
            'threshold': threshold
        }
        
        # Calculate confusion matrix
        self.results['confusion_matrix'] = confusion_matrix(y_true, y_pred)
        
        return metrics
    
    def find_optimal_threshold(
        self,
        y_true: np.ndarray,
        y_proba: np.ndarray,
        metric: str = 'f1'
    ) -> float:
        """
        Find optimal classification threshold
        
        Args:
            y_true: True labels
            y_proba: Predicted probabilities
            metric: Metric to optimize ('f1', 'sensitivity', 'precision')
            
        Returns:
            Optimal threshold
        """
        thresholds = np.arange(0.1, 0.9, 0.01)
        best_score = 0
        best_threshold = 0.5
        
        for threshold in thresholds:
            y_pred = (y_proba >= threshold).astype(int)
            
            if metric == 'f1':
                score = f1_score(y_true, y_pred)
            elif metric == 'sensitivity':
                score = recall_score(y_true, y_pred, pos_label=1)
            elif metric == 'precision':
                score = precision_score(y_true, y_pred, pos_label=1)
            else:
                score = f1_score(y_true, y_pred)
            
            if score > best_score:
                best_score = score
                best_threshold = threshold
        
        return best_threshold
    
    def plot_precision_recall_curve(self, save_path: Optional[str] = None):
        """
        Plot Precision-Recall curve
        
        Args:
            save_path: Path to save figure
        """
        if 'precision' not in self.results:
            print("No PR curve data available. Run calculate_auprc first.")
            return
        
        plt.figure(figsize=(8, 6))
        plt.plot(
            self.results['recall'],
            self.results['precision'],
            'b-',
            label=f"AUPRC = {self.results['auprc']:.3f}"
        )
        plt.xlabel('Recall (Sensitivity)', fontsize=12)
        plt.ylabel('Precision', fontsize=12)
        plt.title('Precision-Recall Curve for AKI Prediction', fontsize=14)
        plt.legend(loc='lower left')
        plt.grid(True, alpha=0.3)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()
    
    def plot_confusion_matrix(self, save_path: Optional[str] = None):
        """
        Plot confusion matrix
        
        Args:
            save_path: Path to save figure
        """
        if 'confusion_matrix' not in self.results:
            print("No confusion matrix available. Run calculate_all_metrics first.")
            return
        
        plt.figure(figsize=(8, 6))
        sns.heatmap(
            self.results['confusion_matrix'],
            annot=True,
            fmt='d',
            cmap='Blues',
            xticklabels=['No AKI', 'AKI'],
            yticklabels=['No AKI', 'AKI']
        )
        plt.xlabel('Predicted', fontsize=12)
        plt.ylabel('Actual', fontsize=12)
        plt.title(f'Confusion Matrix ({self.prediction_window}h Prediction Window)', fontsize=14)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()
    
    def print_summary(self, metrics: Dict[str, float]):
        """
        Print summary of all metrics
        
        Args:
            metrics: Dictionary of calculated metrics
        """
        print("\n" + "="*60)
        print(f"AKI Prediction Metrics ({self.prediction_window}h window)")
        print("="*60)
        
        print("\nPrimary Metrics:")
        print(f"  AUPRC:                {metrics['auprc']:.4f}")
        print(f"  Sensitivity:          {metrics['sensitivity']:.4f}")
        print(f"  Early Pred. Accuracy: {metrics['early_accuracy']:.4f}")
        
        print("\nSecondary Metrics:")
        print(f"  AUROC:                {metrics['auroc']:.4f}")
        print(f"  Precision:            {metrics['precision']:.4f}")
        print(f"  Specificity:          {metrics['specificity']:.4f}")
        print(f"  F1-Score:             {metrics['f1_score']:.4f}")
        print(f"  Overall Accuracy:     {metrics['accuracy']:.4f}")
        print(f"  Optimal Threshold:    {metrics['threshold']:.3f}")
        
        if 'confusion_matrix' in self.results:
            cm = self.results['confusion_matrix']
            print("\nConfusion Matrix:")
            print(f"  True Negatives:  {cm[0, 0]:5d}")
            print(f"  False Positives: {cm[0, 1]:5d}")
            print(f"  False Negatives: {cm[1, 0]:5d}")
            print(f"  True Positives:  {cm[1, 1]:5d}")
        
        print("="*60)


class ModelComparison:
    """
    Compare multiple models on AKI prediction task
    """
    
    def __init__(self, prediction_window: int = 24):
        """
        Initialize model comparison
        
        Args:
            prediction_window: Prediction window in hours
        """
        self.prediction_window = prediction_window
        self.results = {}
        
    def add_model_results(
        self,
        model_name: str,
        y_true: np.ndarray,
        y_proba: np.ndarray
    ):
        """
        Add model results for comparison
        
        Args:
            model_name: Name of the model
            y_true: True labels
            y_proba: Predicted probabilities
        """
        metrics = AKIMetrics(self.prediction_window)
        results = metrics.calculate_all_metrics(y_true, y_proba)
        self.results[model_name] = results
        
    def compare_models(self) -> pd.DataFrame:
        """
        Create comparison table
        
        Returns:
            DataFrame with model comparison
        """
        import pandas as pd
        
        comparison_df = pd.DataFrame(self.results).T
        comparison_df = comparison_df.round(4)
        
        # Sort by AUPRC (primary metric)
        comparison_df = comparison_df.sort_values('auprc', ascending=False)
        
        return comparison_df
    
    def plot_comparison(self, save_path: Optional[str] = None):
        """
        Plot model comparison
        
        Args:
            save_path: Path to save figure
        """
        import pandas as pd
        
        if not self.results:
            print("No results to compare. Add model results first.")
            return
        
        df = self.compare_models()
        metrics_to_plot = ['auprc', 'sensitivity', 'early_accuracy', 'auroc']
        
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        axes = axes.flatten()
        
        for idx, metric in enumerate(metrics_to_plot):
            ax = axes[idx]
            values = df[metric].values
            models = df.index
            
            bars = ax.bar(models, values)
            
            # Color best performing model
            best_idx = np.argmax(values)
            bars[best_idx].set_color('green')
            
            ax.set_ylabel(metric.upper(), fontsize=12)
            ax.set_title(f'{metric.upper()} Comparison', fontsize=14)
            ax.set_ylim([0, 1])
            
            # Add value labels
            for bar, val in zip(bars, values):
                ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                       f'{val:.3f}', ha='center', va='bottom')
        
        plt.suptitle(f'Model Comparison - {self.prediction_window}h Prediction Window', fontsize=16)
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()
        
        return df


if __name__ == "__main__":
    # Example usage
    np.random.seed(42)
    
    # Simulate predictions
    n_samples = 1000
    y_true = np.random.binomial(1, 0.3, n_samples)  # 30% AKI rate
    
    # CNN+BiLSTM+Attention predictions (better performance)
    y_proba_cnn = np.clip(y_true + np.random.normal(0, 0.3, n_samples), 0, 1)
    
    # Transformer predictions (slightly worse)
    y_proba_transformer = np.clip(y_true + np.random.normal(0, 0.4, n_samples), 0, 1)
    
    # Calculate metrics
    print("CNN+BiLSTM+Attention Results:")
    metrics_cnn = AKIMetrics(prediction_window=24)
    results_cnn = metrics_cnn.calculate_all_metrics(y_true, y_proba_cnn)
    metrics_cnn.print_summary(results_cnn)
    
    print("\nTransformer Results:")
    metrics_transformer = AKIMetrics(prediction_window=24)
    results_transformer = metrics_transformer.calculate_all_metrics(y_true, y_proba_transformer)
    metrics_transformer.print_summary(results_transformer)
    
    # Model comparison
    print("\nModel Comparison:")
    comparison = ModelComparison(prediction_window=24)
    comparison.add_model_results("CNN+BiLSTM+Attention", y_true, y_proba_cnn)
    comparison.add_model_results("Transformer", y_true, y_proba_transformer)
    
    comparison_df = comparison.compare_models()
    print(comparison_df)
